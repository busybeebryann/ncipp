﻿Imports System.Data.SqlClient
Imports System.Globalization

Public Class PayrollDateRange
    Dim dtEmployeelist As DataTable
    Private Sub PayrollDateRange_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgvPayroll.DataSource = False
    End Sub
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Try
            If ValidateForm() Then


                dtEmployeelist = GetDataAsTable("SELECT * FROM dbo.tbl_users")


                For iRow = 0 To dtEmployeelist.Rows.Count - 1



                    'before writing in data table , each row should be
                    ' by employee number
                    '1. get loans  wt and contribution of employee
                    '2 . compute the net for each employee

                    'write the date_range 


                Next


            End If

        Catch ex As Exception

        Finally

        End Try
    End Sub
    Private Function ValidateForm() As Boolean
        Dim bReturn As Boolean = True
        'Add Form  Validation Here

        If cboMonth.SelectedIndex = -1 Or cboYear.SelectedIndex = -1 Then
            Return bReturn = False
        End If

    End Function


End Class